package com.cg.bank.service;

import java.util.List;

public interface BankTransactionService {
	   void addTransaction(String msg, String num);
	    List<String> getTransaction(int id);

}
