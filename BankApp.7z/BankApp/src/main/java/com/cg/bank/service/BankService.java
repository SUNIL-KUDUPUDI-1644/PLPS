package com.cg.bank.service;
import java.util.List;
import com.cg.bank.bean.Customer;
import com.cg.bank.exception.BankException;

public interface BankService {
	public boolean addCustomer(Customer cust) throws BankException;
	   

	   
    public String loginByUsername(String username, String password) throws BankException;
   
    public double depositMoney(String accountNo, double amount) throws BankException;
   
    public double withdrawMoney(String accountNo,double amount) throws BankException;
   
    public double showBalance(String accountNo) throws BankException;
   
    public String  fundTransferUpdate(String accountNo1,String accountNo2,double amount) throws BankException;

    Customer getCustomerDetails(String accountNo) throws BankException;

}
