package com.cg.service;

import java.util.List;

import com.c.exception.InvoiceException;
import com.cg.bean.Invoice;

public interface IinvoiceService {
	
	

	
	List<Invoice> viewAllInvoice();
	Invoice createInvoice(Invoice obj);
	Invoice updateInvoice(Invoice obj, int id) throws InvoiceException;
	void deleteInvoice(int i) throws InvoiceException;
	Invoice findSingleInvoice(int id) throws InvoiceException;

}
