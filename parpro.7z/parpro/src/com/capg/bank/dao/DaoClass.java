package com.capg.bank.dao;

import java.util.ArrayList;
import java.util.List;

import com.capg.bank.Bank;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DaoClass implements Dao{
	private static List<Bank> l1 = new ArrayList<Bank>();
	
	static{
		Bank b1 = new Bank("Sunil","pass",1000,123);
		Bank b2 = new Bank("Ajay","gree",1001,100);
		Bank b3 = new Bank("sai", "sai", 1002,10);
		l1.add(b1);
		l1.add(b2);
		l1.add(b3);
	}
	@Override
	public void createAccount(Bank b) {
		l1.add(b);
		b.setList("Account created on  " + getdate());
		System.out.println(b);
		
	}
	@Override
	public Bank showBalance(int accNO) {
		Bank b = new Bank();
		for(Bank b1 : l1) { 
			   if(b1.getAccNo()==accNO)
			   {
				   b=b1;
				   break;
			}
				   
	}
		return b;

	}
	@Override
	public void deposit(int accNO, int amt) {
		Bank b = new Bank();
		for(Bank b1 : l1) { 
			   if(b1.getAccNo()==accNO)
			   {
				   b=b1;
				   break;
			   }
			}
		
		b.setBalance(b.getBalance()+amt);
		System.out.println("amount successfully deposited");
		System.out.println("your new balance :"+ b.getBalance() );
		b.setList("Money deposited "+ amt + " on " + getdate());
	}
	@Override
	public void withDraw(int accNO, int amt) {
		Bank b = new Bank();
		for(Bank b1 : l1) { 
			   if(b1.getAccNo()==accNO)
			   {
				   b=b1;
				   break;
			   }
			}
		if(b.getBalance()>amt)
		{
		b.setBalance(b.getBalance()-amt);
		System.out.println("amount successfully withdrawn");
		System.out.println("your new balance :"+ b.getBalance() );
		b.setList("Money Withdrawn " + amt + " on " + getdate());
		}
		else
			System.out.println("You have INSUFICIENT FUNDS");
				
	}
	@Override
	public void fundTransfer(int accNO, int accNOto, int amt) {
		Bank b = new Bank();
		
		for(Bank b1 : l1) { 
			   if(b1.getAccNo()==accNO)
			   {
				   b=b1;
				   break;
			   }
			}
		Bank b2 = new Bank();
		for(Bank bt : l1) { 
			   if(bt.getAccNo()==accNOto)
			   {
				   b2=bt;
				   if(b2==null)
					   System.out.println("Accountno. not found");
				   break;
			   }
			}
		if(b.getBalance()>amt)
		{
		b.setBalance(b.getBalance()-amt);
		System.out.println("amount successfully withdrawn and credited to recepient account");
		System.out.println("your new balance :"+ b.getBalance() );
		b2.setBalance(b2.getBalance()+amt);
		b.setList("Money transferred from your account of " + amt + " on " + getdate());
		}
		else
			System.out.println("You have INSUFICIENT FUNDS to transfer");
		
	}
	
	
	
	@Override
	public int checkAccno(int accno) {
		boolean b = false;
			for(Bank b1 : l1) { 
				   if(b1.getAccNo()==accno)
				   {
					   b=true;
					  return accno;
				   }
				}
			if(b==false)
			{
				System.out.println("Invalid account no.\n Enter a four digit account no.");
			}
		return 1;
		
	}
	@Override
	public int checkPass(String s) {
		boolean c = false;
		for(Bank b1 : l1) { 
			   if(b1.getPassword().equals(s))
			   {
				   c=true;
				  return 0;
			   }
			}
		if(c==false)
		{
			System.out.println("Wrong Password");
		}
	return 1;
	
		
	}
	public String getdate()
	{
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		String s = df.format(dateobj);
		return s;
	}
	@Override
	public List<String> printTrans1(int accno) {
		
		Bank b = new Bank();
		for(Bank b1 : l1) { 
			   if(b1.getAccNo()==accno)
			   {
				   b=b1;
				   break;
			   }
			}
		return b.getList();
	}

	
	
	
	
	
	
	
	
	
	
}
